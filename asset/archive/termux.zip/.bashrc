alias fedora='proot-distro login fedora --bind /sdcard:/android --isolated'
fedora
